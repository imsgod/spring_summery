package com.example.spring02.service.shop;

import java.util.List;

import com.example.spring02.model.shop.dto.ProductDTO;

public interface ProductService {
	public List<ProductDTO> listProduct();
	public void insertProduct(ProductDTO dto);
	public ProductDTO deatilProduct(int product_id);
	public void deleteProduct(int product_id);
	public void updateProduct(int product_id);
	public String fileInfo(int product_id);
}
