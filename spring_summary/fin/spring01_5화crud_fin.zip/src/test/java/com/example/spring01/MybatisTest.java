package com.example.spring01;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

// junit 4 버전으로 테스트
@RunWith(SpringJUnit4ClassRunner.class)
// 스프링 설정 파일 위치 셋팅.
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml"})
public class MybatisTest {
	private static final Logger LOGGERS = LoggerFactory.getLogger(MybatisTest.class);
	
	//의존 주입
	@Inject
	private SqlSessionFactory sqlFactory;
	
	@Test
	public void testForFactory() {
		 LOGGERS.info("sqlFactory : " + sqlFactory);
	}
	
	@Test
	public void testForSession() {
		 try (SqlSession sqlSession = sqlFactory.openSession()) {
			 LOGGERS.info("sqlSession : " + sqlSession + "\n mybatis 연결 성공");
		 } catch (Exception e) {
			 e.printStackTrace();
		 }
	}

}
