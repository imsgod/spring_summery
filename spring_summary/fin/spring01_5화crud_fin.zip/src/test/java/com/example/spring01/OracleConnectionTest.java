package com.example.spring01;

import java.sql.Connection;
import java.sql.DriverManager;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OracleConnectionTest {
	private static final Logger LOGGERS = 		
							LoggerFactory.getLogger(OracleConnectionTest.class);
	private static String DRIVER = 
							"oracle.jdbc.driver.OracleDriver";
	private static String URL = 
							"jdbc:oracle:thin:@localhost:1521:orcl";
	private static String USER = 
							"spring";
	private static String PWD = 
							"1234";
	
	@Test
	public void test() throws Exception{
		Class.forName(DRIVER);
		try (Connection conn = DriverManager.getConnection(URL, USER, PWD)) {
			LOGGERS.info("Oracle 연결 성공");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
