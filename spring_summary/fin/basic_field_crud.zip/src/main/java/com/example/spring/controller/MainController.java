package com.example.spring.controller;

import java.util.HashMap;
import java.util.Map;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.spring.model.dto.ProductDTO;

@Controller
public class MainController {
	//private static final Logger LOGGERS = LoggerFactory.getLogger(MainController.class);
	
	@RequestMapping("/")
	public String main(Model model) {
		model.addAttribute("message", "홈페이지 환영합니다.");
		return "main";
	}
	
	@RequestMapping("gugu.do")
	public String gugu(Model model,@RequestParam(defaultValue="2")int dan) {
		//int dan = 5;
		String result = "";
		for (int i  = 1; i <= 20; i++) {
			result += dan + " x " + i + " = " + (dan * i) +"<br>";
		}
		model.addAttribute("result", result);
		return "test/gugu";
	}
	
	@RequestMapping("test.do")
	public void test() {}
	
	@RequestMapping("test/doA")
	public String doA(Model model) {
		model.addAttribute("welcome", "환영 합네다.");
		return "test/doA";
	}
	
	@RequestMapping("test/doB")
	public void doB() {}
	
	@RequestMapping("test/doC")
	public ModelAndView doC() {
		Map<String, Object> map = new HashMap<>();
		map.put("product", new ProductDTO("사과", 15000));
		return new ModelAndView("test/doC", "map", map);
	}
	
	@RequestMapping("test/doD")
	public String doD() {
		return "redirect:/test/doE";
	}
	
	@RequestMapping("test/doE")
	public void doE() {}
	
	@ResponseBody
	@RequestMapping("test/doF") 
	public ProductDTO doF() {
		return new ProductDTO("약과",15000);
	}
	
}
