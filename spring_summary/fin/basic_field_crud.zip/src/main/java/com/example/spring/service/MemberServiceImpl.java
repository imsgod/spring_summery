package com.example.spring.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.example.spring.model.dao.MemberDAO;
import com.example.spring.model.dto.MemberDTO;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Inject
	MemberDAO memberDAO;
	
	@Override
	public List<MemberDTO> memberList() {
	 
		return memberDAO.memberList();
	}

	@Override
	public void insertMember(MemberDTO dto) {
		memberDAO.insertMember(dto);
	}

	@Override
	public MemberDTO viewMember(String userid) {
		return memberDAO.viewMember(userid);
	}

	@Override
	public void deleteMember(String userid) {
		memberDAO.deleteMember(userid);

	}

	@Override
	public void updateMember(MemberDTO dto) {
		memberDAO.updateMember(dto);
	}

	@Override
	public boolean passwdChk(String userid, String passwd) {
		return memberDAO.passwdChck(userid, passwd);
	}

}
