package com.example.spring02.service.chart;

import org.json.simple.JSONObject;

public interface GoogleChartService {
	public JSONObject getChartData();
}
   