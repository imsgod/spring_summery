package com.example.spring02.controller.shop;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("shop/cart/*")
public class CartConroller {
	
	//@Inject
	
	@RequestMapping("insert.do")
	public String insert(HttpSession session) {
		String userid = (String) session.getAttribute("userid");
		if (userid == null) {
			return "redirect:/member/login.do";
		}
		return "redirect:/shop/cart/list.do";
	}
}
