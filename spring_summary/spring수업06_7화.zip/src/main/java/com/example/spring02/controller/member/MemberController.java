package com.example.spring02.controller.member;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("member/*")
public class MemberController {
	private static final Logger LOGGERS = LoggerFactory.getLogger(MemberController.class);
	
	@RequestMapping("login.do")
	public String login() {
		return "member/login";
	}
}
